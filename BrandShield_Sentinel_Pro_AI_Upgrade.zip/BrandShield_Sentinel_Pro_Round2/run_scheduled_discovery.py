"""Run bounded public-source discovery for configured, non-placeholder brands.

PythonAnywhere Tasks/cron entry point. Reads the same private environment file
as app.py (~/.brandshield.env by default), so web and scheduled jobs can share
SENTINEL_DB_PATH and optional API keys without putting secrets in the command.
"""
import sys
from app import db, discover_brand_candidates


def main():
    with db() as conn:
        brands = conn.execute("SELECT id, name, website FROM brands ORDER BY id").fetchall()

    if not brands:
        print("No brands configured; nothing to scan.")
        return 0

    attempted = 0
    failed = 0
    for brand in brands:
        website = (brand["website"] or "").strip().lower()
        if website.endswith(".example") or ".example/" in website or website in ("https://example.com", "http://example.com"):
            print(f"SKIP brand_id={brand['id']}: placeholder website must be replaced before real discovery")
            continue
        attempted += 1
        try:
            result = discover_brand_candidates(brand["id"])
            errors = result.get("errors", [])
            source_names = result.get("sources", [])
            print({"brand_id": brand["id"], "brand": brand["name"], **result})
            if not source_names:
                failed += 1
        except Exception as exc:
            failed += 1
            print(f"ERROR brand_id={brand['id']}: {type(exc).__name__}: {str(exc)[:240]}")

    if attempted == 0:
        print("No real brands scanned. Update placeholder brand websites first.")
        return 2
    if failed == attempted:
        print("All discovery attempts failed; inspect the task log and discovery run history.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

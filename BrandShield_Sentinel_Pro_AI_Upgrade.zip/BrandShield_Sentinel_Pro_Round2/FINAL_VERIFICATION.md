# BrandShield Sentinel Pro — deployment and verification status

This package contains the current Flask + SQLite prototype and operational hardening changes. Do not describe the system as an all-platform crawler: source access depends on network policy and provider APIs.

## Implemented in this package

- Public-source discovery connectors: Apple Search API, best-effort Certificate Transparency, optional Brave Search, optional YouTube Data API.
- Candidate deduplication, heuristic risk scoring, evidence records with SHA-256 fingerprints, candidate timeline events, network graph data, report drafts/status workflow, CSV/PDF exports.
- Private environment-file loading shared by web and scheduled task (`~/.brandshield.env` by default).
- Health endpoint reports whether optional connectors are configured without revealing secret values.
- Scheduled discovery skips obvious placeholder domains and returns non-zero status if all attempted discovery runs fail.

## Must be verified on the actual PythonAnywhere account

1. Outbound access to each public source (the prior `crt.sh` request returned HTTP 403; Apple Search API returned HTTP 200).
2. Create/replace the demo placeholder brand with the real brand's official name and website before real monitoring.
3. Configure `SENTINEL_SECRET_KEY`, `SENTINEL_DB_PATH`, and `SENTINEL_ENV=production` in a private `~/.brandshield.env` file, then point WSGI to it.
4. Confirm sign-up/login, brand setup, manual candidate creation, CSV import, discover-now, evidence, network graph, timeline, report draft/status, PDF/CSV exports.
5. Configure and manually run the scheduled task once; inspect task logs and the Report Center discovery history.
6. Run the full test suite in the same PythonAnywhere virtualenv as the web app.
7. Back up the existing live application and database before any production deployment.

## Important limits

- Matching names and domains are unverified leads, not proof of impersonation or fraud.
- No direct crawling of private/restricted social profiles is implemented.
- The app does not automatically submit external platform reports or block accounts.
- A passing unit suite does not prove every external provider is reachable from PythonAnywhere.

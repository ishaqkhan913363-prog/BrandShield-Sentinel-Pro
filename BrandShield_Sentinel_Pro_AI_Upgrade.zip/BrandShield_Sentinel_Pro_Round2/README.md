# BrandShield Sentinel — Full-stack local MVP

A responsive Flask + SQLite threat-intelligence MVP with authorized public-source discovery, case triage, provenance evidence, and reporting workflows.

## Features that work
- Account sign-up and sign-in (passwords are hashed); isolated brand workspace per account.
- Analyst profile with editable display name, sign-in email, and session sign-out.
- Brand profile editing and official-asset registry.
- False-Positive Shield: exact registered official identifiers are skipped on manual add/import.
- Social and app-store candidate management, search, filters, confidence/risk scoring and explainable rationale.
- Re-score saved candidates using the local heuristic engine.
- Investigation status updates, evidence notes, evidence vault.
- CSV import/export with duplicate and official-asset suppression, row validation, and clear import summaries.
- Paginated, filterable monitoring with highest-risk cases prioritized first.
- Workspace-wide risk summaries, campaign-cluster hints, scan history, settings, responsive UI.
- Scam Network Intelligence: correlate exact observed URLs, payment URLs, phone numbers, domains, and app publishers across cases; inspect provenance and export linked evidence.
- SQLite persistence; records survive app restarts.

## Quick start
Requires Python 3.10+.

### macOS / Linux
```bash
cd BrandShield_Sentinel_Pro
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

### Windows PowerShell
```powershell
cd BrandShield_Sentinel_Pro
py -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

Open http://127.0.0.1:5000

CSV imports are limited to 5 MB and 10,000 rows per upload. Repeated records, registered official identifiers, and invalid rows are skipped and counted in the completion summary.

## Deploy on PythonAnywhere
See [PYTHONANYWHERE.md](./PYTHONANYWHERE.md) for the WSGI setup, virtual environment, secure production secret, SQLite storage, and reload steps. Production mode requires `SENTINEL_SECRET_KEY`, uses secure session cookies, enables CSRF protection, and does not seed the demo account in a fresh database.

### Scam Network Intelligence
Open **Scam network** from the workspace navigation. The module extracts identifiers from candidate URLs, descriptions and app publisher fields already in the workspace, then builds evidence-backed case links. The graph shows observed field, timestamp and source-quality metadata for each shared identifier. Link strength is an explainable heuristic—not a probability, attribution, or finding of wrongdoing. Cases marked false positive remain visible but are excluded from links. Common platform domains and `.example` demo domains do not create domain-only links; indicators shared by more than 25 cases are suppressed as broad infrastructure. Use **Export investigation** to download linked evidence as CSV. The sample import includes two explicitly synthetic records sharing an illustrative payment URL so you can demonstrate the graph; do not treat them as real observations. No network requests are made to the listed candidate sources.

Correlation weights are visible in the graph view: payment URL 94, exact URL or phone 90, domain 55 and publisher 48. A small adjustment applies the lower provenance weight across the two records (manual/CSV 0.60, built-in synthetic demo 0.35, other source 0.50). These values are transparent but uncalibrated prioritization heuristics, not probabilities or trust ratings. Add optional `observed_at` values in manual entry or CSV as timezone-aware ISO 8601 (for example `2026-10-14T08:00:00Z`). When a source timestamp was not provided, the graph explicitly labels the record-capture time instead.

### Run workflow checks
```bash
python -m unittest discover -s tests
```

### Demo login
- Email: `demo@sentinel.local`
- Password: `SentinelDemo!26`

You can create a separate account using Sign up. The first launch creates a demo workspace with clearly illustrative records.

## CSV import format
Required columns: `channel,name`
Optional columns: `url,developer,description,logo_match,observed_at`

Example:
```csv
channel,name,url,developer,description,logo_match,observed_at
Social,Northstar Support Desk,https://social.example/northstar-help,,Urgent account recovery,0,2026-10-14T08:00:00Z
App Store,Northstar Wallet Plus,https://store.example/apps/northstar-wallet,Unknown Studio,Companion wallet,1,
```
`channel` accepts `Social` or `App Store` (also `app` / `store`).

## Important boundaries
This is a functional local MVP, not a production threat-intelligence service. It does **not** crawl social networks or app stores and it does not call platform APIs. The scan button re-scores records already stored in your workspace. Sample records and demo metrics are synthetic. Candidate risk is a triage signal, not a finding of fraud or malicious intent. Similarity alone is not proof.

To enable live monitoring, add approved connectors for the exact sources you have permission to access, respect platform terms and rate limits, store source URLs/timestamps, and record connector health/errors. Logo similarity currently uses a manually marked `logo_match` field; it does not run image embeddings or perceptual hashing.

## Evidence integrity, timeline and executive reports
- Newly recorded evidence includes a SHA-256 fingerprint over the evidence type, capture timestamp and note text. This detects later changes to that stored text but is not a digital signature or proof that the source itself is authentic.
- The Threat timeline records app-observed events from the time this upgrade is enabled, including new discoveries, status changes and evidence additions. It does not recreate older events that were never logged.
- Report Center offers executive CSV and PDF downloads. PDF export uses ReportLab, included in `requirements.txt`.
- Candidate-level timeline data is available to authenticated users at `/api/candidates/<id>/timeline`.

## Before internet deployment
1. Set `SENTINEL_ENV=production` and a long random `SENTINEL_SECRET_KEY`; use HTTPS and secure session cookies.
2. Back up the SQLite database and verify recovery. Migrate to managed PostgreSQL if concurrency or scale requires it.
3. Add rate limits, account recovery and operational alerting before handling sensitive or business-critical data.
4. Review privacy, retention, authorization and security with your team.
5. Keep synthetic demo data clearly labeled; do not present it as live findings.


## Automated discovery (Round 2 upgrade)

Threat Monitoring now includes **Discover threats now**. It queries public Certificate Transparency records for look-alike domain leads and Apple's public app search endpoint. If `BRAVE_SEARCH_API_KEY` is configured server-side, it also searches indexed public web results for the brand, Google Play listing pages, and some indexed public social pages. If `YOUTUBE_API_KEY` is configured, it queries the official YouTube Data API for public channel metadata. New results are deduplicated, scored with the existing heuristic engine, saved with provenance evidence, and shown in the monitoring table. These results are leads, not verified abuse.

### Enable scheduled scans

The scheduler is a separate process so it works with hosting providers that terminate long-running web processes. Configure a PythonAnywhere Scheduled Task to run every six hours if your account plan supports the desired schedule; otherwise run it at the highest allowed frequency. Command (replace the path with your deployed project path):

```bash
cd /home/YOUR_USERNAME/BrandShield_Sentinel_Pro && /home/YOUR_USERNAME/.virtualenvs/YOUR_VENV/bin/python run_scheduled_discovery.py
```

The task must use the same database path and environment variables as the web app. Set `SENTINEL_DB_PATH` consistently if using a non-default database. Configure `BRAVE_SEARCH_API_KEY` and, optionally, `YOUTUBE_API_KEY` in the scheduled task environment as well as the web app environment. Review run history at **Report center**.

### Report Center

Candidate pages can prepare report drafts with the candidate URL, risk rationale and observed details. Drafts can be downloaded and their workflow status tracked. Updating a status does **not** submit a report externally. External submission requires the platform's official reporting process or a separately authorized integration.

### Coverage and limitations

- Certificate Transparency exposes certificate records, not site intent; results may be benign.
- Apple search only covers its indexed app catalog; it does not enumerate all mobile apps.
- Brave search is optional and returns indexed public pages, not every account or private profile.
- No direct Instagram/Facebook crawler, Google Play catalog crawler, or automatic external account blocking is included.
- A scan error is stored in discovery run history. A successful request is not proof that all threats were found.
- For production use, add rate limiting, robust background queueing, platform-approved integrations, stronger monitoring and a reviewed privacy/retention policy.


## AI Threat Analyst (LLM integration)

The AI Threat Analyst uses the OpenAI Responses API to analyze the active brand's candidate observations, analyst evidence notes and available timeline events. It is optional and disabled until `OPENAI_API_KEY` is configured on the server. The default model is `gpt-5.4-mini`; change `SENTINEL_LLM_MODEL` to another model available to your API project.

Add these values to the private runtime environment file outside the project directory (never commit or paste the real key into chat):

```text
OPENAI_API_KEY=your_private_api_key
SENTINEL_LLM_MODEL=gpt-5.4-mini
```

Reload the web app and open **AI threat analyst** in the sidebar. The analysis history is stored in the current SQLite workspace. The request sets `store: false` for the Responses API, but that setting is not a substitute for reviewing provider account, privacy, retention, and organizational data-handling policies. Only the active brand's data is included in a request. Candidate URLs and imported text are treated as untrusted input.

The LLM is used for reasoning and report drafting—not live discovery. Discovery still depends on configured search connectors and scheduled jobs. The AI does not automatically change case status, submit platform reports, or assert that a candidate is malicious. Human review is required. API access and billing are separate from ChatGPT subscriptions.

The health endpoint `/api/health` reports whether an AI key is configured, but never exposes the key. `/api/ai/status` is authenticated.

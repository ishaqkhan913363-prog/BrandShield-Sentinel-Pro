# Deploy BrandShield Sentinel on PythonAnywhere

This guide deploys the Flask + SQLite MVP, including limited public-source discovery, evidence fingerprints, case timeline, and executive report exports. Source coverage depends on network access, configured API keys, quotas, and platform rules.

## 1. Upload the application

Create a PythonAnywhere account and upload the project files using the **Files** page, or clone the project from a Git repository in a Bash console. Keep the project under your home directory, for example:

```text
/home/YOUR_USERNAME/BrandShield_Sentinel_Pro
```

Do not upload `.venv`, `.env`, or a local `sentinel.db`. Start with a fresh production database so the built-in demo account and synthetic workspace are not carried to the public site.

## 2. Create a virtual environment

In **Web → Add a new web app**, choose **Manual configuration** and a Python version available in your account. Use the same Python version in a PythonAnywhere Bash console:

```bash
mkvirtualenv --python=/usr/bin/python3.13 brandshield-venv
workon brandshield-venv
cd ~/BrandShield_Sentinel_Pro
pip install -r requirements.txt
```

Replace `python3.13` with the version you selected if PythonAnywhere shows a different executable. In the Web tab, set **Virtualenv** to:

```text
/home/YOUR_USERNAME/.virtualenvs/brandshield-venv
```

## 3. Configure private runtime settings

Generate a long random session secret in the PythonAnywhere Bash console:

```bash
python -c "import secrets; print(secrets.token_urlsafe(48))"
```

Create a private environment file outside the project. Replace the placeholder with your generated secret. Do not paste real secrets into chat, screenshots, GitHub, or the project ZIP.

```bash
nano ~/.brandshield.env
```

Add these lines (keep the values on one line; no spaces around `=`):

```text
SENTINEL_ENV=production
SENTINEL_SECRET_KEY=PASTE_YOUR_GENERATED_RANDOM_SECRET_HERE
SENTINEL_DB_PATH=/home/YOUR_USERNAME/.brandshield-data/sentinel.db
# Optional: only add keys if you obtain them; never share them publicly.
# BRAVE_SEARCH_API_KEY=your_key_here
# YOUTUBE_API_KEY=your_key_here
# Optional LLM integration (separate API billing may apply)
OPENAI_API_KEY=your_private_api_key
SENTINEL_LLM_MODEL=gpt-5.4-mini
```

Save, then restrict file permissions:

```bash
mkdir -p ~/.brandshield-data
chmod 700 ~/.brandshield-data
chmod 600 ~/.brandshield.env
```

Open the WSGI configuration file linked from the **Web** tab. Set the paths before importing the application; replace `YOUR_USERNAME` with your PythonAnywhere username:

```python
import os
import sys

project_home = "/home/YOUR_USERNAME/BrandShield_Sentinel_Pro"
os.environ["SENTINEL_ENV_FILE"] = "/home/YOUR_USERNAME/.brandshield.env"
if project_home not in sys.path:
    sys.path.insert(0, project_home)

from app import app as application
```

The application loads the private environment file before reading its settings. Production mode requires the secret, uses secure session cookies over HTTPS, enables CSRF protection, and does not create the built-in demo account on a fresh database. Register your own account on the site.

## 4. Configure static files and reload

In the **Web** tab, optionally add a static files mapping:

| URL | Directory |
| --- | --- |
| `/static/` | `/home/YOUR_USERNAME/BrandShield_Sentinel_Pro/static/` |

Click **Reload** for your web app. Visit the `your-username.pythonanywhere.com` address shown in the Web tab, create your account, and verify sign-in, candidate entry, CSV import, the scam-network page, and CSV export.

## 5. Backups and operating notes

- Back up `/home/YOUR_USERNAME/.brandshield-data/sentinel.db` regularly. Do not put the database in a temporary directory.
- Test a backup restore before relying on it. SQLite is suitable for this single-instance prototype, not a high-volume multi-worker service.
- Keep `.env`, the WSGI secret, and the database private. Rotate the session secret deliberately; changing it signs out existing sessions.
- PythonAnywhere does not automatically configure optional platform integrations. Apple search is attempted without a key; Brave Search and YouTube Data API require server-side keys. The app does not directly crawl Instagram/Facebook or submit external reports.
- Risk scores and graph links are review aids, not proof of fraud or common ownership. The supplied sample data is synthetic.
- This is still a prototype: review account recovery, rate limiting, logging, retention and privacy requirements before using sensitive or business-critical data.

## Troubleshooting

- **Import error / application failed to start:** verify the WSGI `project_home` and that the Web tab uses the virtualenv where `requirements.txt` was installed. Read the error log linked from the Web tab.
- **Missing secret error:** set `SENTINEL_SECRET_KEY` in the WSGI config and click Reload.
- **CSRF token missing:** use the forms rendered by the app, enable browser cookies, and reload the page after deploying. All state-changing forms require a CSRF token.
- **Database cannot be opened:** verify `data_home` exists and is writable by your PythonAnywhere user; keep the SQLite database out of read-only/static folders.


## Scheduled automated discovery

1. Back up the existing database and application folder before deploying.
2. Upload `run_scheduled_discovery.py` alongside `app.py`.
3. The scheduled script reads `~/.brandshield.env` through the same loader as the web app, so both use the same `SENTINEL_DB_PATH` and optional API keys. If your home directory differs, set `SENTINEL_ENV_FILE` in the task command.
4. Optionally add `BRAVE_SEARCH_API_KEY` for indexed public web results and `YOUTUBE_API_KEY` for official YouTube Data API channel search to the private environment file. Keep both keys server-side only; never put them in templates, JavaScript, screenshots, or GitHub. These connectors are optional; Apple search does not need a key.
5. Replace demo placeholder websites such as `northstar.example` before scheduling real discovery. The scheduled task deliberately skips placeholder domains.
5. In PythonAnywhere **Tasks**, create a scheduled task using your virtualenv's Python executable, for example:

```bash
cd /home/YOUR_USERNAME/BrandShield_Sentinel_Pro && /home/YOUR_USERNAME/.virtualenvs/YOUR_VENV/bin/python run_scheduled_discovery.py
```

Use the cadence allowed by your PythonAnywhere plan. If six-hourly tasks are unavailable, use the highest permitted frequency. Check the task log and Report Center run history after the first run.

`Discover threats now` also runs from the authenticated Threat Monitoring page. It can take several seconds while public sources respond. It never auto-reports or blocks an external account.

## Evidence Vault file uploads (added update)

The Evidence Vault now accepts PNG, JPG/JPEG, WEBP and PDF files up to 5 MB. Uploads are checked against file signatures, SHA-256 is computed from the actual uploaded bytes, and metadata records the linked candidate, upload timestamp, uploader, size, content type and review status. Downloads and review actions require login and are scoped to the active brand.

Files are stored outside the public `static` directory, by default in `~/.brandshield_evidence`. To choose a different private directory, set `SENTINEL_EVIDENCE_PATH` in the web app environment. Ensure that directory is writable by the PythonAnywhere web app user and is not exposed as a static/public directory. The new `evidence_files` table is created automatically on startup; the existing evidence notes table is unchanged. Keep backups of both the SQLite database and the private evidence storage directory.


## AI Threat Analyst setup

To enable the LLM analyst, add `OPENAI_API_KEY` and optionally `SENTINEL_LLM_MODEL` to `~/.brandshield.env` (outside the project), then set restrictive permissions with `chmod 600 ~/.brandshield.env` and reload the web app. Never put the API key in templates, JavaScript, source control, or a public ZIP. Open **AI threat analyst** from the sidebar and run a case or workspace analysis. The app sends only the selected brand context needed for that analysis to the provider. Review privacy and retention obligations before sending customer or confidential data.

This integration does not make threat discovery automatic by itself. Configure the existing scheduled-discovery task and supported source API keys separately. AI output is advisory; analysts must verify original sources before taking action.

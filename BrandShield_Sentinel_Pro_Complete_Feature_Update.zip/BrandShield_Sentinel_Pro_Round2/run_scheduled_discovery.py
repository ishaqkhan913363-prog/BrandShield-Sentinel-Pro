"""Run by a PythonAnywhere scheduled task (or cron) every six hours.
Uses the same SENTINEL_DB_PATH and API environment variables as the web app.
"""
from app import db, discover_brand_candidates


def main():
    with db() as conn:
        brand_ids = [row["id"] for row in conn.execute("SELECT id FROM brands ORDER BY id").fetchall()]
    for brand_id in brand_ids:
        result = discover_brand_candidates(brand_id)
        print({"brand_id": brand_id, **result})


if __name__ == "__main__":
    main()
